---
title: Welcome Story
description: An interactive introduction to the LODEON workbench.
keywords:
  - LODEON
  - knowledge graphs
  - introduction
language: en
updatedAt: 2026-08-23T21:12:03.825Z
lodeon:
  htmlMeta:
    description: An interactive introduction to the LODEON workbench.
    keywords:
      - LODEON
      - knowledge graphs
      - introduction
    language: en
  openGraph:
    title: Welcome Story
    description: An interactive introduction to the LODEON workbench.
    type: article
  jsonLd:
    "@context": https://schema.org
    "@type": ScholarlyArticle
    headline: Welcome Story
    name: Welcome Story
    description: An interactive introduction to the LODEON workbench.
    keywords:
      - LODEON
      - knowledge graphs
      - introduction
    inLanguage: en
    dateModified: 2026-08-23T21:12:03.825Z
---

# Welcome to LODEON

## Explore knowledge graphs with AI, work with evidence, and turn your findings into meaningful data stories.

LODEON is an AI-assisted authoring and exploration workbench for knowledge graphs. It brings together structured data exploration, note-taking, visualizations, executable queries, and AI assistance in one data souvereign workspace. Your project, your chats and your data are always stored locally in your browser. You decide which knowledge graphs and AI models LODEON connects to, and you can export your complete work as a portable project at any time.

## Start exploring

This page is already a LODEON project. Edit the text, run the example nodes, add your own notes, or remove anything you do not need.

- **Run a SPARQL query** — explore the configured knowledge graph and inspect its results directly in your story.
- **Ask the AI Assistant** — investigate a topic or request help building a query, visualization, or narrative.
- **Combine evidence and interpretation** — place notes, query results, maps, charts, media, and other special nodes in one document.

### Try your first SPARQL node

Select "Run" in the following special node to retrieve data from the Culture Knowledge Graph. You can change the query and continue working with the results.

```shmarql {title="Overview of data items in the Culture Knowledge Graph" kg="culture-kg"}
PREFIX schema: <http://schema.org/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?feed (MIN(COALESCE(STR(?rdfsLabel), STR(?schemaName), STR(?feed))) AS ?feedLabel) (COUNT(DISTINCT ?item) AS ?recordCount) WHERE {
  ?feed <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> schema:DataFeed.
  ?feed schema:dataFeedElement ?item.
  OPTIONAL {
    ?feed rdfs:label ?rdfsLabel.
  }
  OPTIONAL {
    ?feed schema:name ?schemaName.
  }
}
GROUP BY ?feed
ORDER BY DESC (?recordCount) (LCASE(?feedLabel))
OFFSET 0
LIMIT 100
```

## Learn more

- **Read the LODEON documentation**
- **Explore a complete demo story**
- **View and contribute to the source code**

Ready for an empty workspace? Select **New**. Already have a LODEON project? Select **Import**.
